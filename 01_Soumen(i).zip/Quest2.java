import java.util.*;
class Quest2
{
    public static void main()
    {
        Scanner in=new Scanner(System.in);
        System.out.println("ENTER a");
        int a=in.nextInt();
        System.out.println("ENTER b");
        int b=in.nextInt();
        System.out.println("ENTER c");
        int c=in.nextInt();
        double r1,r2;
        double d=b*b-4*a*c;
        if(d>0)
        {
            r1=(-b+Math.sqrt(d)/(2*a));
            r2=(-b-Math.sqrt(d)/(2*a));
            System.out.println("root1 = "+r1+" root2= "+r2);
        }
        else if(d==0)
        {
            r1=r2=-b/(2*a);
            System.out.println("roots are equal= "+r1);
        }
        else
        {
            int real =-b/(2*a);
            int img=(int)Math.sqrt(-d)/(2*a);
            System.out.println(real+" + "+img+"i");
        }
    }

}