import java.util.*;
class Quest10
{
    public static void main()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("ENTER THE RANGE");
        int n=in.nextInt();
        System.out.println("ENTER THE VALUE");
        double x=in.nextDouble();
        double sum=0;
        int i=1;
        for(int j=1;j<=n;j++)
        {
            if(j%2==0)
            {
                sum=sum-((Math.pow(x,i))/fact(i));
                i=i+2;
            }
            else
            {
                sum=sum+((Math.pow(x,i))/fact(i));
                i=i+2;
            }
        }
        System.out.println(sum);
    }
    static int fact(int n)
    {
        int f=1;
        for(int i=1;i<=n;i++)
        {
            f=f*i;
        }
        return f;
    }
}