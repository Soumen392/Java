
import java.util.*;
class Quest1
{
    public static void main()
    {
        Scanner in=new Scanner (System.in);
        System.out.println("enter 1st COORDINATE x1 and y1");
        int x1=in.nextInt();
        int y1=in.nextInt();
        System.out.println("ENTER 2ND COORDINATE x2 and y2");
        int x2=in.nextInt();
        int y2=in.nextInt();
        System.out.println("ENTER 3RD COORDINATE x3 and y3");
        int x3=in.nextInt();
        int y3=in.nextInt();
        double x=Math.sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
        double y=Math.sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
        double z=Math.sqrt((x3-x1)*(x3-x1)+(y3-y1)*(y3-y1));
        double area=0;
        System.out.println(x+" "+y+" "+z);
        if(x+y>z && y+z>x && z+x>y)
        {
            if(x==y && y==z && z==x)
            {
                System.out.println("EQUILATERAL TRIANGLE");
                area=((1/2)*x*y);
                System.out.println("THE AREA IS = " +area);
                
            }
            if(x>y && y>z)
            {
                if(x*x==y*y+z*z)
                {
                    System.out.println("RIGHT ANGLED TRIANGLE");
                    area=((1/2)*y*z);
                    System.out.println("THE AREA IS= " +area);
                }
            }
            else if(y>x && x>z)
            {
                if(y*y==x*x+z*z)
                {
                    System.out.println("RIGHT ANGLED TRIANGLE");
                    area = ((1/2)*x*z);
                    System.out.println("THE AREA IS = " +area);
                }     
            }
            else if (z>y && y>x)
            {
                if(z*z==y*y+x*x)
                {
                    System.out.println("RIGHT ANGLED TRIANGLE");
                    area=((1/2)*x*y);
                    System.out.println("THE AREA IS = " +area);
                }
            }
        }
        else
        {
            System.out.println("TRIANGLE NOT POSSIBLE");
        }       
    }
}