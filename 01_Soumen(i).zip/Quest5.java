import java.util.*;
class Quest5
{
    public static void main()
    {
        Scanner in = new Scanner (System.in);
        System.out.println("ENTER THE NUMBER");
        int n=in.nextInt();
        String t="";
        
        for(int i=2;i<=n;i++)
        {
            if(n%i==0)
            {
                t=t+" "+(i+"");
                n=n/i;
                i=i-1;
            }
        }
        System.out.println(t);
    }
}