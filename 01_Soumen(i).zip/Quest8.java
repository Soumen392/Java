import java.util.*;
class Quest8
{
    public static void main()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("ENTER THE STARTING RANGE");
        int m=in.nextInt();
        System.out.println("ENTER THE ENDING RANGE");
        int n=in.nextInt();
        int sum=0,cpy;
        for(int i=m;i<=n;i++)
        {
            if(isPrime(i)==1)
            {
                sum=sum+i;
            }
        }
        System.out.println("THE SUM OF ALL PRIME NUMBERS ARE = "+sum);
    }
    static int isPrime(int n)
    {
        int c=0;
        for(int i=1;i<=n;i++)
        {
            if(n%i==0)
            {
                c=c+1;
            }
        }
        if(c==2)
        return 1;
        else
        return 0;
    }
}