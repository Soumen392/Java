import java.util.*;
class Quest4
{
    public static void main()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("ENTER THE NUMBER");
        int n=in.nextInt();
        int sum=0;
        for(int i=1;i<n;i++)
        {
            if(n%i==0)
            {
                sum=sum+i;
            }
        }
        if(sum==n)
        {
            System.out.println(n+" IS PERFECT NUMBER");
        }
        else
        {
            System.out.println(n+" IS NOT A PERFECT NUMBER");
        }
    }
}