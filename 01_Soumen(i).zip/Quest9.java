import java.util.*;
class Quest9
{
    public static void main()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("ENTER THE LIMIT");
        int n=in.nextInt();
        double sum=0;
        int i=1;
        for(int j=1;j<=n;j++)
        {
            if(j%2==0)
            {
                sum=sum-((Math.pow(i,j))/j);
                i=i+2;
            }
            else
            {
                sum=sum+((Math.pow(i,j))/j);
                i=i+2;
            }
        }
        System.out.print(sum);
    }
}