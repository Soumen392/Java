import java.util.*;
class Quest7
{
    public static void main()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("ENTER THE STARTING RANGE");
        int m=in.nextInt();
        System.out.println("ENTER THE ENDING RANGE");
        int n=in.nextInt();
        int sum=0,cpy;
        for(int i=m;i<=n;i++)
        {
            if(isArmstrong(i)==i)
            {
                System.out.print(i+"  ");
            }
        }
    }
    static int isArmstrong(int n)
    {
        int sum=0;
        int l=(n+"").length();
        while(n!=0)
        {
            int d=n%10;
            sum=sum+(int)Math.pow(d,l);
            n=n/10;
        }
        return sum;
    }
}       