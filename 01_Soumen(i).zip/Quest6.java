import java.util.*;
class Quest6
{
    public static void main()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("ENTER THE NUMBER");
        int n=in.nextInt();
        int cpy=n;
        int sum=0;
        while(cpy!=0)
        {
            int d=cpy%10;
            sum=sum+fact(d);
            cpy=cpy/10;
        }
        if(sum==n)
        {
            System.out.println(n+" IS A PEARSON NUMBER");
        }
        else
        {
            System.out.println(n+" IS NOT PEARSON NUMBER");
        }
    }
    static int fact(int n)
    {
        int f=1;
        for(int i=1;i<=n;i++)
        {
            f=f*i;
        }
        return f;
    }
}