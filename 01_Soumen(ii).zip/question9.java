import java.util.*;
class question9 
{
    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);
        System.out.println("ENTER SIZE OF ROW AND COLOUMNS");
        int m=in.nextInt();
        int n=in.nextInt();
        int[][] array = new int[m][n]; 
        System.out.println("ENTER ELEMENTS OF ARRAY");
        for(int i=0;i<m;i++)
        {
            for(int j=0;j<n;j++)
            {
                array[i][j]=in.nextInt();
            }
        }
        System.out.println("Elements that are maximum in their row and column:");

        // Loop through each element in the 2D array
        for (int i = 0; i < array.length; i++) {
            for (int j = 0; j < array[i].length; j++) {
                int currentElement = array[i][j];
                boolean isMaxInRow = true;
                boolean isMaxInColumn = true;

                // Check if currentElement is the maximum in its row
                for (int k = 0; k < array[i].length; k++) {
                    if (array[i][k] > currentElement) {
                        isMaxInRow = false;
                        break;
                    }
                }

                // Check if currentElement is the maximum in its column
                for (int k = 0; k < array.length; k++) {
                    if (array[k][j] > currentElement) {
                        isMaxInColumn = false;
                        break;
                    }
                }

                // If the element is maximum in both its row and column, print it
                if (isMaxInRow && isMaxInColumn) {
                    System.out.println("Element at [" + i + "][" + j + "] = " + currentElement);
                }
            }
        }
    }
}
