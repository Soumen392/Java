import java.util.*;
class question5 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the purchase price: ");// Input the purchase price
        double purchasePrice = scanner.nextDouble();// Input the years of service
        System.out.print("Enter the years of service: ");
        int yearsOfService = scanner.nextInt();
        System.out.print("Enter the annual depreciation: ");
        double annualDepreciation = scanner.nextDouble();// Input the annual depreciation
        double totalDepreciation = annualDepreciation * yearsOfService;// Calculate total depreciation
        double salvageValue = purchasePrice - totalDepreciation;// Calculate the salvage value
        System.out.println("The salvage value of the item is: " + salvageValue);
    }
}
