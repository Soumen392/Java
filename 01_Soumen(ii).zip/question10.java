import java.util.*;
class question10 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);// Constants
        final int SP_COUNT = 4; // Number of salespeople
        final int PROD_COUNT = 5; // Number of products
        // Sales array
        double[][] sales = new double[SP_COUNT][PROD_COUNT];
        // Input sales data
        System.out.println("Enter sales data (salesperson product value), 0 to stop:");
        while (true) 
        {
            int sp = scanner.nextInt();
            if (sp == 0) break; // Exit on 0
            int prod = scanner.nextInt();
            double value = scanner.nextDouble();
            if (sp >= 1 && sp <= SP_COUNT && prod >= 1 && prod <= PROD_COUNT) 
            {
                sales[sp - 1][prod - 1] += value; // Add value to sales array
            } else 
            {
                System.out.println("Invalid input.");
            }
        }

        // Print the summary
        System.out.println("Product   SP1      SP2      SP3      SP4      Total");
        System.out.println("---------------------------------------------------");

        for (int j = 0; j < PROD_COUNT; j++) 
        {
            System.out.print("Product " + (j + 1) + "  ");
            double productTotal = 0;
            for (int i = 0; i < SP_COUNT; i++) 
            {
                System.out.print(sales[i][j] + "      "); // Sales for each salesperson
                productTotal += sales[i][j]; // Total for product
            }
            System.out.println("| " + productTotal); // Product total
        }
        // Print totals for salespeople
        System.out.print("Total     ");
        for (int i = 0; i < SP_COUNT; i++) {
            double spTotal = 0;
            for (int j = 0; j < PROD_COUNT; j++) {
                spTotal += sales[i][j]; // Total for each salesperson
            }
            System.out.print(spTotal + "      "); // Print total for salesperson
        }
        System.out.println(); // New line for formatting
    }
}
