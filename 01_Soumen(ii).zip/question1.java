import java.util.*;
class question1
{
    public static void main()
    {
        Scanner in = new Scanner(System.in);//scanner class
        System.out.println("ENTER THE NUMBER OF STUDENTS");
        int n=in.nextInt();
        int marks[]=new int[n];//array for marks
        System.out.println("ENTER MARKS OF STUDENTS");
        int count81_100,count61_80,count41_60,count0_40;
        count81_100=count61_80=count41_60=count0_40=0;//setting counter to zero
        for(int i=0;i<n;i++)
        {
            marks[i]=in.nextInt();
            if(marks[i]>=81 && marks[i]<=100)
            {
                count81_100++;//counting for 81 to 100
            }
            else if(marks[i]>=61 && marks[i]<=80)
            {
                count61_80++;//counting for 61 to 80
            }
            else if(marks[i]>=41 && marks[i]<=60)
            {
                count41_60++;//counting for 41 to 60
            }
            else
            {
                count0_40++;// count for 0 to 40
            }
        }
        System.out.println("STUDENTS WITH MARKS IN RANGE 81 TO 100 = "+count81_100);//printing the values
        System.out.println("STUDENTS WITH MARKS IN RANGE 61 TO 80 = "+count61_80);
        System.out.println("STUDENTS WITH MARKS IN RANGE 41 TO 60 = "+count41_60);
        System.out.println("STUDENTS WITH MARKS IN RANGE 0 TO 40 = "+count0_40);
    }
}