import java.util.*;
class question2
{
    public static void main()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("ENTER THE NUMBER OF STUDENTS");
        int n=in.nextInt();//taking number of students input from user
        for(int i=1;i<=n;i++)
        {
            System.out.println("ENTER MARKS OF STUDENT " +i);
            System.out.println("ENTER MARKS OF MATHEMATICS");//maths marks
            int math=in.nextInt();
            System.out.println("ENTER MARKS OF PHYSICS");//physics marks
            int physics=in.nextInt();
            System.out.println("ENTER MARKS OF CHEMISTRY");//chemistry marks
            int chemistry=in.nextInt();
            int total=math + physics + chemistry;//total marks of all three subjects
            int mat_phy=math + physics;//marks of physics and maths
            if((math>=60 && physics>=50 && chemistry>=40 && total>=200) || mat_phy>=150)//checking for the admission condition
            {
                System.out.println("STUDENT "+i+" IS ELIGIBLE");
            }
            else
            {
                System.out.println("STUDENT "+i+" IS NOT ELIGIBLE");
            }
        }
    }
}