import java.util.*;
class question6 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the inductance L (in henries): ");// Input inductance L
        double L = scanner.nextDouble();
        System.out.print("Enter the resistance R (in ohms): ");// Input resistance R
        double R = scanner.nextDouble();
        System.out.println("Capacitance (C)     Frequency");// Print the table header
        for (double C = 0.01; C <= 0.1; C += 0.01) {
            // Calculate the damped natural frequency
            double frequency = Math.sqrt((1 / (L * C)) - (Math.pow(R, 2) / (4 * Math.pow(C, 2))));

            // Print the capacitance and frequency
            System.out.println(C + "                " + frequency);
        }
    }
}
