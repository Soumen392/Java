import java.util.*;
class question8 
{
    public static void main(String[] args) 
    {
        Scanner scanner = new Scanner(System.in);
        int[] count = new int[5];// Array to hold vote counts for candidates 1 to 5
        int spoiledBallots = 0;
        System.out.println("Enter the votes (1-5 for candidates, 0 to stop):");
        while(true) 
        {
            int vote = scanner.nextInt();
            if (vote == 0) // Check if user wants to stop voting
            {
                break;
            }
            if (vote >= 1 && vote <= 5) // Count votes or spoiled ballots
            {
                int votes=vote-1;
                count[votes]=count[votes]+1; // Increment the count for the valid candidate
            } else 
            {
                spoiledBallots++; // Increment the count for spoiled ballots
            }
        }
        System.out.println("Vote counts:");
        for (int i = 0; i < count.length; i++) 
        {
            System.out.println("Candidate " + (i + 1) + ": " + count[i] + " votes");
        }
        System.out.println("Spoilt ballots: " + spoiledBallots);
    }
}
