import java.util.*;
class question4 
{

    public static void main(String[] args) 
    {
        Scanner in = new Scanner(System.in);
        System.out.print("Enter the number of resistors: ");// Ask for the number of resistors
        int numResistors = in.nextInt();
        double totalInverseResistance = 0.0;// Loop to get each resistor value
        for (int i = 1; i <= numResistors; i++) 
        {
            System.out.print("Enter resistance R" + i + " in ohms: ");
            double resistance = in.nextDouble();
            totalInverseResistance += 1.0 / resistance; // Add the inverse of the resistance
        }

        // Calculate the equivalent resistance
        double equivalentResistance = 1.0 / totalInverseResistance;
        System.out.println("The equivalent resistance of the resistors in parallel is: " + equivalentResistance + " ohms");
    }
}
