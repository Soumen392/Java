import java.util.*;
class question7
{
    public static void main()
    {
        Scanner in = new Scanner(System.in);
        System.out.println("ENTER SIZE OF 1ST ARRAY");
        int m=in.nextInt();
        System.out.println("ENTER SIZE OF 2ND ARRAY");
        int n=in.nextInt();
        int a[]=new int[m];//1st array
        int b[]=new int[n];//2nd array
        int c[]=new int[m+n];//3rd array for size of 1st and 2nd array
        System.out.println("ENTER VALUES OF 1ST ARRAY");
        for(int i=0;i<m;i++)
        {
            a[i]=in.nextInt();//input from user in 1st array
        }
        System.out.println("ENTER VALUES OF 2ND ARRAY");
        for(int i=0;i<n;i++)
        {
            b[i]=in.nextInt();//input from user in 2nd array
        }
        int count=0;
        for(int i=0;i<m;i++)
        {
            c[count++]=a[i];//inserting values of 1st array in 3rd
        }
        for(int i=0;i<n;i++)
        {
            c[count++]=b[i];//inserting values of 2nd array in 3rd
        }
        Arrays.sort(c);
        System.out.println("MERGED SORTED ARRAY");
        for(int i=0;i<(m+n);i++)
        {
            System.out.print(c[i]+" ");//printing the merged array
        }
    }
}