class question3 
{
    public static void main(String[] args) 
    {
        // Print the table header
        System.out.println("Principal   Rate      Years     Future Value");
        System.out.println("------------------------------------------------");

        // Loop through Principal values from 1000 to 10000 in increments of 1000
        for (int P = 1000; P <= 10000; P += 1000) 
        {
            // Loop through interest rates from 0.10 to 0.20 in increments of 0.01
            for (double r = 0.10; r <= 0.20; r += 0.01) 
            {
                // Loop through time periods from 1 to 10 years
                for (int n = 1; n <= 10; n++) 
                {
                    // Calculate future value
                    double V = P * Math.pow(1 + r, n);
                    // Print the values 
                    System.out.println(P + "        " + r + "     " + n + "     " + V);
                }
            }
        }
    }
}
