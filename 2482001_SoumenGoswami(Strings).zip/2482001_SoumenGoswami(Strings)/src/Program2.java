public class Program2 {

    public static void main(String[] args) {
        System.out.println("No of arguments-" + args.length + "\t");

        for (String arg : args) {
            System.out.print(arg.charAt(0));
        }
    }
}
