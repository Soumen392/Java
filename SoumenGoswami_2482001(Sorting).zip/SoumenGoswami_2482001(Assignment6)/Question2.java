import java.util.Arrays;

public class Question2 {
    public static void main(String[] args) {
        int [] arr1 = {5,4,3,2,1};
        mergeSort(arr1,0, arr1.length);
        System.out.println(Arrays.toString(arr1));
        int[] arr2 = {5,7,6,9,2};
        quickSort(arr2,0, arr2.length - 1);
        System.out.println(Arrays.toString(arr2));


    }
    public static void mergeSort(int[] arr, int start, int end){
        if (end - start == 1){
            return;
        }
        int mid = start + ( end - start)/2;

        // here I divide my array
        mergeSort(arr,start,mid);
        mergeSort(arr,mid,end);

        //then I conquer
        mergeInplace(arr,start,mid,end);

    }
    private static void mergeInplace(int[] arr, int start, int mid, int end) {
        int [] mix = new int[end - start];
        int i = start;
        int j = mid;
        int k = 0;
        while(i < mid && j < end){
            if(arr[i] < arr[j]){
                mix[k] = arr[i];
                i++;
            }
            else {
                mix[k] = arr[j];
                j++;
            }
            k++;
        }

        while (i < mid){
            mix[k] = arr[i];
            i++;
            k++;
        }
        while(j < end){
            mix[k] = arr[j];
            j++;
            k++;
        }

        for(int l = 0; l < mix.length; l++) {
            arr[start+l] = mix[l];
        }
    }

    static void quickSort(int[] arr, int low, int high) {
        int start = low;
        int end = high;
        int mid = start + (end - start) / 2;
        int pivot = arr[mid];

        if (low >= high) {
            return;
        }

        while (start <= end) {
            if (arr[start] < pivot) {
                start++;
            }
            if (arr[end] > pivot) {
                end--;
            }
            if (start <= end) {
                int temp = arr[start];
                arr[start] = arr[end];
                arr[end] = temp;
                start++;
                end--;
            }
        }
        //now my pivot is placed in correct position now sort remaining two halves
        quickSort(arr, low, end);
        quickSort(arr, start, high);
    }
}
