import java.util.Arrays;

public class Question1 {
    public static void main(String[] args) {
        int[] arr1 = {5,4,3,2,1};
        int[] arr2 = {5,4,7,9,1};
        selectionSort(arr1);
        System.out.println(Arrays.toString(arr1));
        insertionSort(arr2);
        System.out.println(Arrays.toString(arr2));
    }
    static void selectionSort(int[] arr){
        for (int i = 0; i < arr.length; i++) {
            // here I take the smallest element's index
            int smallest = i;
            for (int j = i+1; j < arr.length; j++) {
                //now checking the smallest element is greater than the next element
                if(arr[smallest] > arr[j]){
                    //if it's smaller, then update it
                    smallest = j;
                }
            }
            //here I will sort my array in ascending order
            // if my current element is greater than the smallest, I will swap it
            int temp = arr[i];
            arr[i] = arr[smallest];
            arr[smallest] = temp;
        }
    }

    static void insertionSort(int[] arr){
        for (int i = 1; i < arr.length; i++) {
            int curr = arr[i];
            int j = i - 1;
            while(j >=0 && curr < arr[j] ){
                //here we use the loop to track the sorted part
                arr[j+1] = arr[j];
                j--;
            }
            //placement
            arr[j+1] = curr;
        }
    }
}
