class Ping implements Runnable{
    Thread t;
    Ping(){
        t = new Thread (this,"Ping");
        System.out.println("Child Thread"+t);
        t.start();
    }
    public void run(){
        try{
            for (int i = 0; i < 5; i++){
                System.out.println("Child thread = " + "Ping");
                Thread.sleep(1000);

            }
        }catch(InterruptedException e){
            System.out.println(e);
        }
        System.out.println("Ping is existing");
    }
}

public class Pingpong {
    public static void main(String[] args) {
        Ping ob = new Ping();
        try{
            for(int i = 0; i < 5; i++){
                System.out.println("Pong thread = "+"Pong");
                Thread.sleep(1000);
            }
        }catch(InterruptedException e){
            System.out.println(e);
        }
        System.out.println("Main Existing");
    }
}
