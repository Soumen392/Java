class MyThread extends Thread {
    public void run() {
        for (int i = 0; i < 5; i++) {
            System.out.println(Thread.currentThread().getName() + " - Count: " + i);
            if (i == 2) {
                System.out.println(Thread.currentThread().getName() + " is yielding...");
                Thread.yield(); // Yield control to other threads
            }
            try {
                Thread.sleep(500); // Sleep for 500 milliseconds
            } catch (InterruptedException e) {
                System.out.println(Thread.currentThread().getName() + " interrupted!");
            }
        }
        System.out.println(Thread.currentThread().getName() + " has completed execution.");
    }
}

public class ThreadExperiment {
    public static void main(String[] args) {
        MyThread thread1 = new MyThread();
        MyThread thread2 = new MyThread();

        System.out.println("Starting Thread 1...");
        thread1.start();

        System.out.println("Starting Thread 2...");
        thread2.start();

        System.out.println("Thread 1 is alive: " + thread1.isAlive());
        System.out.println("Thread 2 is alive: " + thread2.isAlive());

        synchronized (thread1) {
            try {
                System.out.println("Main thread waiting for Thread 1 to complete...");
                thread1.wait(2000); // Waiting for thread1 with timeout
            } catch (InterruptedException e) {
                System.out.println("Main thread interrupted while waiting.");
            }
        }

        // Using deprecated stop() method (for illustration only)
        try {
            System.out.println("Stopping Thread 2 (not recommended)...");
            //noinspection removal
            thread2.stop();
        } catch (ThreadDeath e) {
            System.out.println("Thread 2 stopped forcefully.");
        }

        System.out.println("Thread 1 is alive: " + thread1.isAlive());
        System.out.println("Thread 2 is alive: " + thread2.isAlive());

        System.out.println("Main thread completed.");
    }
}
