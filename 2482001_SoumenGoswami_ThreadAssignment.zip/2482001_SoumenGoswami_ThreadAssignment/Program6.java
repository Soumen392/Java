class T1 extends Thread {
    private T2 t2;

    public T1(T2 t2) {
        this.t2 = t2;
    }

    public void run() {
        synchronized (t2) {
            try {
                System.out.println("T1 is waiting...");
                t2.wait();  // Wait for notification from T2
                System.out.println("T1 received notification!");
            } catch (InterruptedException e) {
                System.out.println("T1 was interrupted: " + e.getMessage());
            }
        }
    }
}

class T2 extends Thread {
    private T1 t1;

    public T2(T1 t1) {
        this.t1 = t1;
    }

    public void run() {
        try {
            Thread.sleep(2000);  // Simulate delay for 2 seconds
            synchronized (t1) {
                System.out.println("T2 is notifying T1...");
                t1.notifyAll();  // Notify T1 after waiting
            }
        } catch (InterruptedException e) {
            System.out.println("T2 was interrupted: " + e.getMessage());
        }
    }
}

public class Program6 {
    public static void main(String[] args) {
        T1 t1 = new T1(null);  // Create T1 with a null reference for now
        T2 t2 = new T2(t1);    // Create T2 with the T1 reference
        t1 = new T1(t2);       // Now update T1 with the correct reference for T2

        t1.start();  // Start T1
        t2.start();  // Start T2
    }
}