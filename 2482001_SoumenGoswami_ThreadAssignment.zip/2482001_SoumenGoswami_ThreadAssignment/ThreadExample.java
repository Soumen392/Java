class Self extends Thread {
    public Self() {
        System.out.println("Thread starting...");
    }

    public void run() {
        try {
            for (int i = 0; i < 3; i++) {
                System.out.println("Running...");
                Thread.sleep(1000);
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void finalize() {
        System.out.println("Thread shutting down...");
    }
}

class GarbageCollectorThread extends Thread {
    public void run() {
        System.out.println("Calling System.gc() and System.runFinalization()...");
        System.gc();
        System.runFinalization();
    }
}

public class ThreadExample {
    public static void main(String[] args) {
        Self t1 = new Self();
        Self t2 = new Self();
        GarbageCollectorThread gcThread = new GarbageCollectorThread();

        t1.start();
        t2.start();
        gcThread.start();
    }
}