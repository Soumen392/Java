class ThreadOne extends Thread {
    private Thread threadTwo;

    public ThreadOne(Thread threadTwo) {
        this.threadTwo = threadTwo;
    }

    public void run() {
        synchronized (threadTwo) {
            try {
                System.out.println("ThreadOne is waiting...");
                threadTwo.wait();  // Wait until notified by threadTwo
                System.out.println("ThreadOne received notification!");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}

class ThreadTwo extends Thread {
    private Thread threadOne;

    public ThreadTwo(Thread threadOne) {
        this.threadOne = threadOne;
    }

    public void run() {
        try {
            Thread.sleep(2000);  // Wait for 2 seconds before notifying
            synchronized (threadOne) {
                System.out.println("ThreadTwo is notifying ThreadOne...");
                threadOne.notifyAll();  // Notify threadOne to continue
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}

public class Program5 {
    public static void main(String[] args) {
        ThreadOne t1 = new ThreadOne(new ThreadTwo(null));
        ThreadTwo t2 = new ThreadTwo(t1);

        t1.start();
        t2.start();
    }
}
