import java.util.HashSet;

public class problem4 {
    public static void main(String[] args) {
        int[] array1 = {1, 2, 3, 4, 5};
        int[] array2 = {9,9};

        if (isSubset(array1, array2)) {
            System.out.println("Array2 is a subset of Array1");
        } else {
            System.out.println("Array2 is not a subset of Array1");
        }
    }

    public static boolean isSubset(int[] array1, int[] array2) {
        // Use a HashSet to store elements of array1
        HashSet<Integer> set = new HashSet<>();
        for (int element : array1) {
            set.add(element);
        }

        // Check if all elements of array2 are in the set
        for (int element : array2) {
            if (!set.contains(element)) {
                return false;
            }
        }
        return true;
    }
}
