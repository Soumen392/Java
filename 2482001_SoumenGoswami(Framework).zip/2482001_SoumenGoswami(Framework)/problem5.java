import java.util.ArrayList;
import java.util.HashSet;

public class problem5 {
    public static void main(String[] args) {
        int[] array1 = {1, 2, 3, 4, 5};
        int[] array2 = {2, 4, 6};

        int[] difference = findDifference(array1, array2);

        System.out.println("Elements present in the first array but not in the second array:");
        for (int element : difference) {
            System.out.print(element + " ");
        }
    }

    public static int[] findDifference(int[] array1, int[] array2) {

        HashSet<Integer> set = new HashSet<>();
        for (int element : array2) {
            set.add(element);
        }


        ArrayList<Integer> differenceList = new ArrayList<>();

        for (int element : array1) {
            if (!set.contains(element)) {
                differenceList.add(element);
            }
        }


        int[] differenceArray = new int[differenceList.size()];
        for (int i = 0; i < differenceList.size(); i++) {
            differenceArray[i] = differenceList.get(i);
        }

        return differenceArray;
    }
}
