// Interface 1
interface Interface1 {
    void method1();
    void method2();
}

// Interface 2
interface Interface2 {
    void method3();
    void method4();
}

// Interface 3
interface Interface3 {
    void method5();
    void method6();
}

interface NewInterface extends Interface1, Interface2, Interface3 {
    void method7();
}

class ConcreteClass {
    void concreteMethod() {
        System.out.println("I'm from Concrete method...");
    }
}

// Class implementing the new interface and inheriting from ConcreteClass
class CombinedClass extends ConcreteClass implements NewInterface {
    @Override
    public void method1() {
        System.out.println("I'm from methhod1...");
    }

    @Override
    public void method2() {
        System.out.println("I'm from methhod2...");
    }

    @Override
    public void method3() {
        System.out.println("I'm from methhod3...");
    }

    @Override
    public void method4() {
        System.out.println("I'm from methhod4...");
    }

    @Override
    public void method5() {
        System.out.println("I'm from methhod5...");
    }

    @Override
    public void method6() {
        System.out.println("I'm from methhod6...");
    }

    @Override
    public void method7() {
        System.out.println("I'm from methhod7...");
    }
}

// Methods that accept each of the interfaces as arguments
class InterfaceHandler {
    static void handleInterface1(Interface1 obj) {
        obj.method1();
        obj.method2();
    }

    static void handleInterface2(Interface2 obj) {
        obj.method3();
        obj.method4();
    }

    static void handleInterface3(Interface3 obj) {
        obj.method5();
        obj.method6();
    }

    static void handleNewInterface(NewInterface obj) {
        obj.method7();
    }
}

// Main class
public class Quest1 {
    public static void main(String[] args) {
        // Create an instance of the class
        CombinedClass obj = new CombinedClass();

        // Pass the object to the methods
        InterfaceHandler.handleInterface1(obj);
        InterfaceHandler.handleInterface2(obj);
        InterfaceHandler.handleInterface3(obj);
        InterfaceHandler.handleNewInterface(obj);

        // Call a method from the concrete class
        obj.concreteMethod();
    }
}
