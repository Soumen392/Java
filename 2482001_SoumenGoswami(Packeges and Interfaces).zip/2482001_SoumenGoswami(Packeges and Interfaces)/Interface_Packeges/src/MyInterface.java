// Public interface
public interface MyInterface {
    void displayMessage();
}
