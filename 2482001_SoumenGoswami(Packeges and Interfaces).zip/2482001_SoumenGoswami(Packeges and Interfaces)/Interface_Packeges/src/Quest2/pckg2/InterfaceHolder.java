package Quest2.pckg2;


import Quest2.pckg1.MyInterface;

public class InterfaceHolder {

    // Protected inner class implementing the interface
    public class InnerClass implements MyInterface {
        @Override
        public void method() {
            System.out.println("Message from InnerClass in OuterClass.");
        }
    }
}
