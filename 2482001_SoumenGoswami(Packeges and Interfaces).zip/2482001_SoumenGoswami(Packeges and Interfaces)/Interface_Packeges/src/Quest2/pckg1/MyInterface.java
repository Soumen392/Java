package Quest2.pckg1;

public interface MyInterface {
    void method();
}
