package Quest2.pckg3;

import Quest2.pckg1.MyInterface;
import Quest2.pckg2.InterfaceHolder;

public class Derived_Class extends InterfaceHolder{

    public MyInterface getInnerClassObject() {
        return new InnerClass();
    }

    public static void main(String[] args) {

        Derived_Class derived = new Derived_Class ();
        MyInterface obj = derived.getInnerClassObject();
        obj.method();
    }
}
