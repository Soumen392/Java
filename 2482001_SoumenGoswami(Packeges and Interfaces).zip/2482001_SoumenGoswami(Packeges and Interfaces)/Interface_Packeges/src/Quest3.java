
class OuterClass {
    private class InnerClass implements MyInterface {
        @Override
        public void displayMessage() {
            System.out.println("I'm from inner class");
        }
    }

    public MyInterface getInnerClassInstance() {
        return new InnerClass(); // Upcasting
    }
}

public class Quest3 {
    public static void main(String[] args) {
        OuterClass outer = new OuterClass();
        MyInterface obj = outer.getInnerClassInstance();
        obj.displayMessage();

    }
}
