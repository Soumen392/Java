package Quest5.Shapes;

public interface Shape{
    double area();
    double perimeter();
}
