import Quest5.Shapes.Circle;
import Quest5.Shapes.Shape;
import Quest5.Shapes.Square;
import Quest5.Shapes.Triangle;

import java.util.Scanner;

public class Shape_Cal {public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);

    System.out.println("Choose a shape to calculate area and perimeter:");
    System.out.println("1. Circle");
    System.out.println("2. Square");
    System.out.println("3. Triangle");

    int choice = scanner.nextInt();

    switch (choice) {
        case 1: // Circle
            System.out.print("Enter the radius of the circle: ");
            double radius = scanner.nextDouble();
            Shape circle = new Circle (radius);
            System.out.println("Area: " + circle.area());
            System.out.println("Perimeter: " + circle.perimeter());
            break;

        case 2: // Square
            System.out.print("Enter the side length of the square: ");
            double side = scanner.nextDouble();
            Shape square = new Square (side);
            System.out.println("Area: " + square.area());
            System.out.println("Perimeter: " + square.perimeter());
            break;

        case 3: // Triangle
            System.out.print("Enter the lengths of the three sides of the triangle (a, b, c): ");
            double a = scanner.nextDouble();
            double b = scanner.nextDouble();
            double c = scanner.nextDouble();
            if (a + b > c && a + c > b && b + c > a) { // Valid triangle condition
                Shape triangle = new Triangle (a, b, c);
                System.out.println("Area: " + triangle.area());
                System.out.println("Perimeter: " + triangle.perimeter());
            } else {
                System.out.println("The provided dimensions do not form a valid triangle.");
            }
            break;

        default:
            System.out.println("Invalid choice.");
            break;
    }

    scanner.close();
}
}