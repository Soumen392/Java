import java.util.*;

//7. Create a program with multi-dimensional List to store customer details (customerId,
//customerName, customerCity).
//This program to search the customer based on the customerName from a given array.

class Customer {
    int customerId;
    String customerName;
    String customerCity;

    // Constructor
    public Customer(int id, String name, String city) {
        this.customerId = id;
        this.customerName = name;
        this.customerCity = city;
    }

    // To print customer details
    @Override
    public String toString() {
        return "CustomerID: " + customerId + ", Name: " + customerName + ", City: " + customerCity;
    }
}

public class CustomerManager_Quest7 {
    private List<Customer> customers;

    // Constructor to initialize customer details for five customers
    public CustomerManager_Quest7() {
        customers = new ArrayList<>();
        customers.add(new Customer(101, "Soumen", "Bankura"));
        customers.add(new Customer(102, "Ajay", "Kolkata"));
        customers.add(new Customer(103, "Rahul", "Jalpaiguri"));
        customers.add(new Customer(104, "Rakes", "Durgapur"));
        customers.add(new Customer(105, "Vicky", "Shiliguri"));

        // Sort customers by name for binary search
        customers.sort(Comparator.comparing(c -> c.customerName));
    }

    // Method to search for a customer using Binary Search (based on Name)
    public Customer binarySearchCustomer(String name) {
        int left = 0, right = customers.size() - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            Customer midCustomer = customers.get(mid);

            int compare = midCustomer.customerName.compareToIgnoreCase(name);
            if (compare == 0) {
                return midCustomer; // Customer found
            } else if (compare < 0) {
                left = mid + 1; // Search in the right half
            } else {
                right = mid - 1; // Search in the left half
            }
        }
        return null; // Customer not found
    }

    // Method to get customer details by ID
    public Customer getCustomer(int customerId) {
        for (Customer customer : customers) {
            if (customer.customerId == customerId) {
                return customer;
            }
        }
        return null; // Not found
    }

    // Method to sort customers based on City using Insertion Sort
    public void sortCustomer() {
        int n = customers.size();
        for (int i = 1; i < n; i++) {
            Customer key = customers.get(i);
            int j = i - 1;

            // Move elements that are greater than key to one position ahead
            while (j >= 0 && customers.get(j).customerCity.compareToIgnoreCase(key.customerCity) > 0) {
                customers.set(j + 1, customers.get(j));
                j--;
            }
            customers.set(j + 1, key);
        }
    }

    // Display all customers
    public void displayCustomers() {
        for (Customer customer : customers) {
            System.out.println(customer);
        }
    }

    // Main method for testing
    public static void main(String[] args) {
        CustomerManager_Quest7 manager = new CustomerManager_Quest7();

        System.out.println("Customer list (sorted by Name for Binary Search):");
        manager.displayCustomers();

        // Searching for a customer by name
        String searchName = "Soumen";
        Customer foundCustomer = manager.binarySearchCustomer(searchName);
        System.out.println("\nSearching for customer '" + searchName + "':");
        System.out.println(foundCustomer != null ? foundCustomer : "Customer not found.");

        // Sorting customers based on City
        manager.sortCustomer();
        System.out.println("\nCustomer list (sorted by City):");
        manager.displayCustomers();

        // Fetching a customer by ID
        int searchId = 103;
        System.out.println("\nFetching details for customer ID " + searchId + ":");
        Customer customerById = manager.getCustomer(searchId);
        System.out.println(customerById != null ? customerById : "Customer not found.");
    }
}
