public class Orthogonal_Quest6 {

    // Method to calculate transpose of a matrix
    public static int[][] transpose(int[][] matrix) {
        int n = matrix.length;
        int[][] transposed = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                transposed[j][i] = matrix[i][j];
            }
        }
        return transposed;
    }

    // Method to multiply two matrices
    public static int[][] multiply(int[][] A, int[][] B) {
        int n = A.length;
        int[][] result = new int[n][n];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    result[i][j] += A[i][k] * B[k][j];
                }
            }
        }
        return result;
    }

    // Method to check if a matrix is an identity matrix
    public static boolean isIdentity(int[][] matrix) {
        int n = matrix.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if ((i == j && matrix[i][j] != 1) || (i != j && matrix[i][j] != 0)) {
                    return false;
                }
            }
        }
        return true;
    }

    // Method to check if a matrix is orthogonal
    public static boolean isOrthogonal(int[][] matrix) {
        int[][] transposeMatrix = transpose(matrix);
        int[][] product = multiply(transposeMatrix, matrix);

        return isIdentity(product);
    }

    // Method to calculate the 1-norm of a matrix
    public static int oneNorm(int[][] matrix) {
        int n = matrix.length;
        int maxSum = 0;

        for (int j = 0; j < n; j++) {
            int columnSum = 0;
            for (int i = 0; i < n; i++) {
                columnSum += Math.abs(matrix[i][j]);
            }
            maxSum = Math.max(maxSum, columnSum);
        }
        return maxSum;
    }

    // Main method to test the program
    public static void main(String[] args) {
        int[][] matrix = {
                {1, 0},
                {0, -1}
        };

        System.out.println("Is the matrix orthogonal? " + isOrthogonal(matrix));
        System.out.println("1-Norm of the matrix: " + oneNorm(matrix));
    }
}

