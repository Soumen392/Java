//2. Create a Class BasicSort within that implement three Generic methods that can implement the
//BubbleSort(), SelectionSort(), InsertionSort() that can sort of any type of data.

import java.util.Arrays;

public class Sorting_Quest1 {
    public static void main(String[] args) {
        Integer[] arr = {5,1,4,8,9,7,6};
//        bubbleSort(arr);
//        selection(arr);
        insertion(arr);
        System.out.println("Sorted Array: "+ Arrays.toString(arr));
    }

    static <T extends Comparable<T>> void bubbleSort(T[] arr){
        boolean Is_swapped;
        for(int i = 0;i<arr.length - 1;i++){
            Is_swapped = false;
            for (int j = 0; j < arr.length - i -1; j++) {
                if(arr[j].compareTo(arr[j+1]) > 0){
                    T temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                    Is_swapped = true;
                }
            }
            if(!Is_swapped){
                break;
            }
        }
    }

    static <T extends Comparable<T>> void selection(T[] arr){
        for (int i = 0; i < arr.length - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < arr.length; j++) {
                if(arr[j].compareTo(arr[minIndex]) < 0){
                 minIndex = j;
                }
            }

            T temp = arr[minIndex];
            arr[minIndex] = arr[i];
            arr[i] = temp;

        }
    }

    static <T extends  Comparable <T>> void insertion(T[] arr){
        for (int i = 0; i <= arr.length - 2; i++) {
            for(int j = i + 1; j > 0; j--) {
                if(arr[j].compareTo(arr[j-1]) < 0){
                    T temp = arr[j];
                    arr[j] = arr[j-1];
                    arr[j-1] = temp;
                }
                else {
                    break;
                }

            }

        }

    }
}
