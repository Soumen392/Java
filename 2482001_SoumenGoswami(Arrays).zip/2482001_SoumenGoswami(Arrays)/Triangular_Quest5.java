//5. Write a Class CheckTriangular within that implement methods to check whether a matrix is
//i) Lower triangular ii) Upper triangular iii) Diagonal iv) Identity v) Tridiagonal.

public class Triangular_Quest5 {

    public static boolean isLowerTriangular(int[][] matrix) {
        int n = matrix.length;
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (matrix[i][j] != 0) {
                    return false;
                }
            }
        }
        return true;
    }


    public static boolean isUpperTriangular(int[][] matrix) {
        int n = matrix.length;
        for (int i = 1; i < n; i++) {
            for (int j = 0; j < i; j++) {
                if (matrix[i][j] != 0) {
                    return false;
                }
            }
        }
        return true;
    }
    public static boolean isDiagonal(int[][] matrix) {
        int n = matrix.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (i != j && matrix[i][j] != 0) {
                    return false;
                }
            }
        }
        return true;
    }

    public static boolean isIdentity(int[][] matrix) {
        int n = matrix.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if ((i == j && matrix[i][j] != 1) || (i != j && matrix[i][j] != 0)) {
                    return false;
                }
            }
        }
        return true;
    }

    public static boolean isTridiagonal(int[][] matrix) {
        int n = matrix.length;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (Math.abs(i - j) > 1 && matrix[i][j] != 0) {
                    return false;
                }
            }
        }
        return true;
    }

    // Main method for testing
    public static void main(String[] args) {
        int[][] matrix = {
                {1, 2, 0},
                {3, 4, 5},
                {0, 6, 7}
        };

        System.out.println("Lower Triangular: " + isLowerTriangular(matrix));
        System.out.println("Upper Triangular: " + isUpperTriangular(matrix));
        System.out.println("Diagonal: " + isDiagonal(matrix));
        System.out.println("Identity: " + isIdentity(matrix));
        System.out.println("Tridiagonal: " + isTridiagonal(matrix));
    }
}

