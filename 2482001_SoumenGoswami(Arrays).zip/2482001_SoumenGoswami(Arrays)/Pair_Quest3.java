//3. Write a Generic method that computes the Second minimum and Second maximum elements
//of an array of type T and returns a pair containing the minimum and maximum value.

public class Pair_Quest3<T,U>{
    private final T first;
    private final U second;
    public Pair_Quest3(T first,U second){
        this.first = first;
        this.second = second;
    }
    public T getFirst(){
        return first;
    }

    public U getSecond() {
        return second;
    }

    @Override
    public String toString(){
        return  "(" + first +","+ second+ ")";
    }

    public static void main(String[] args) {
        Integer [] arr = {5,2,9,7,1,3,8};
        Pair_Quest3<Integer,Integer> result = Minmax.findminMax(arr);
        System.out.println("Min: "+result.getFirst()+", Max: "+result.getSecond());
    }
}

class Minmax {

    public static  <T extends Comparable <T> > Pair_Quest3<T,T> findminMax(T[] arr){
        if(arr == null || arr.length < 2){
            throw new IllegalArgumentException("Array must contain two elements");
        }
        T min = arr[0], secondMin = null;
        T max = arr[0], secondMax = null;

        for (T element : arr) {
            if(element.compareTo(min) < 0){
                secondMin = min;
                min = element;
            } else if (secondMin == null || element.compareTo(secondMin) < 0  && element.compareTo(min) > 0) {
                secondMin = element;
            }
            if (element.compareTo(max) > 0){
                secondMax = max;
                max = element;
            } else if (secondMax == null || element.compareTo(secondMax) > 0 && element.compareTo(max) < 0) {
                secondMax = element;
            }
        }
        if (secondMin == null || secondMax == null){
            throw new IllegalArgumentException("Array must contain at least two values");
        }

        return new Pair_Quest3<>(secondMin,secondMax);
    }

}
