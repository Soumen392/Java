//1. Create a Class Search within that implement two Generic method LinearSearch(),
//BinarySearch(). Test your program for different data.

public class Searching_Quest2 {
    public static void main(String[] args) {
        Integer [] arr = {1,4,5,8,9,7};
        Integer target = 8;
        System.out.println("Your target element is found using binary search at index no: "+binary(arr,target));
        System.out.println("Your target element is found using linear search at index no: "+linear(arr,target));
    }
    static <T extends Comparable<T>> int binary(T[]arr, T target ){
        int start = 0;
        int end = arr.length - 1;
        while(start <= end){
            int mid = start + ( end - start) / 2;
            int comparison = arr[mid].compareTo(target);

             if (comparison == 0) {
                return mid;
            }
            else if (comparison < 1){
                start = mid + 1;
            }
            else{
                end = mid - 1;
             }
        }
        return -1;
    }

    static <T> int linear(T[] arr,T target){
        for (int i = 0; i < arr.length; i++) {
            if(arr[i].equals(target)){
                return i;
            }
        }
        return -1;
    }



}
