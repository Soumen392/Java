
import java.util.ArrayList;
class stack<T>{
	public T[] arr;
	public int top=-1;
	stack(int s){
		arr=(T[]) new Object[s]; ;
	}
	void push(T x) {
		top++;
		arr[top]=x;
		System.out.println(arr[top]+" added into the stack");
	}
	void pop() {
		top--;
	}
	void display() {
		System.out.println("full stack is:----");
		for(int i=0;i<=top;i++) {
			System.out.println(arr[i]);
		}
	}
	void peek() {
		System.out.println("top element is "+arr[top]);
	}
}


public class Assignment_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		stack<Integer> s=new stack<>(5);
		s.push(10);
		s.push(15);
		//s.push("54");
		s.display();
		s.pop();
		s.display();
		s.peek();
		
		stack<String> s1=new stack<>(5);
		s1.push("raja");
		s1.push("abcd");
		s1.push("54");
		s1.display();
		s1.pop();
		s1.display();
		s1.peek();
	}

}
