/*4. Write a generic method that computes the Second minimum and Second maximum elements of an array
of type T and returns a pair containing the minimum and maximum value.*/

import java.util.Arrays;

public class Assignment_4 {

	static <T> void minmax(T arr[]) {
		T arr1[]=(T[]) new Object[2];
		Arrays.sort(arr);
		arr1[0]=arr[1];
		arr1[1]=arr[arr.length-2];
		System.out.println("minimum element= "+arr1[0]+" maximum element ="+arr1[1]);
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Integer[] a= {1,8,2,7,25,18,2,4};
		System.out.println("the array is:"+Arrays.toString(a));
		minmax(a);
		
		System.out.println("");
		
		String s[]= {"s","g","w","a","n","b","c","f","s"};
		System.out.println("before sorting:"+Arrays.toString(s));
		minmax(s);
	}

}
