

	class queue<T>{
		public T[] arr;
		int front=-1;
		int rear=-1;
		int size;
		queue(int s){
			this.size=s;
			arr=(T[]) new Object[size];
			front++;
			
		}
		void enqueue(T x) {
			if(isfull()) {
				rear++;
				arr[rear]=x;
				System.out.println(arr[rear]+" added into the queue");
			}
			else {
				System.out.println("queue is full");
			}
		}
		void dequeue() {
			if(isempty()) {
				
				System.out.println(arr[front]+" successfully poped");
				front++;
			}
			else {
				System.out.println("queue is empty");
			}
		}
		void display() {
			if(isempty()) {
				System.out.println("queue is:----");
				int j=rear;
				for(int i=front;i<=j;i++) {
					System.out.println(arr[i]);
				}
			}
		}
		boolean isfull() {
			if(arr.length<rear+1) {
				return false;
			}
			else {
				return true;
			}
			
		}
		boolean isempty() {
			if(front>rear) {
				return false;
			}
			return true;
		}
	}

public class Assignment_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		queue<Integer> q=new queue<>(5);
		q.enqueue(10);
		q.enqueue(15);
		q.enqueue(12);
		q.display();
		q.dequeue();
		q.dequeue();
		q.display();
		
		queue<String> q1=new queue<>(5);
		q1.enqueue("hello");
		q1.enqueue("world");
		q1.enqueue("12");
		q1.display();
		q1.dequeue();
		q1.dequeue();
		q1.display();
	}

}
